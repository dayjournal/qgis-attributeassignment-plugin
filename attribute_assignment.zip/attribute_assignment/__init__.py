def classFactory(iface):
    from .attribute_assignment import AttributeAssignment

    return AttributeAssignment(iface)
